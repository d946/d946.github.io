import js
js.eval("alert('Hello from JavaScript')")
